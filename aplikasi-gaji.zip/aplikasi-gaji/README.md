Kelompok 9

Anggota :
1. Amalia Fitri Falahan - 14197075
2. Aditia Nuzlar - 14197077
3. Aulia Rahman Syah - 14197045
4. Gianlyardi Jethro Timoti Rusli - 14197072
5. Angga Prayudha Putra - 14197043

Aplikasi Penggajian 

Codeigniter 3

Fitur Admin
1. CRUD Data Karyawan
2. CRUD Data Jabatan
3. Setting Potongan Gaji
4. Tambah Data Absensi Karyawan
5. Data Gaji
6. Laporan Gaji
7. Laporan Absensi
8. Cetak Slip Gaji
9. Ubah Password Admin

Fitur Karyawan
1. Data Gaji 
2. Cetak Slip Gaji
3. Ubah Password Karyawan



